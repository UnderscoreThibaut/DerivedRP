resource.AddFile("materials/darkrp/darkrpderma.png")
