DarkRP.declareChatCommand{
    command = "enablestorm",
    description = "Enable meteor storms.",
    delay = 1.5,
    condition = hasCommandsPriv
}

DarkRP.declareChatCommand{
    command = "disablestorm",
    description = "Disable meteor storms.",
    delay = 1.5,
    condition = hasCommandsPriv
}
